
package string.manipulation.challenge;

import java.util.Scanner;




public class StringManipulationChallenge {

    
    public static void main(String[] args) {
        System.out.println("Enter your username: ");
      Scanner scanner = new Scanner(System.in);
      String username = scanner.nextLine();
        System.out.println("");
      
      System.out.println("Enter your Password: ");
String password = scanner.nextLine();
        System.out.println("");
        
        
String firstName = "Steve";
	String surname  = "Smith";
	char initial = firstName.charAt(0);

System.out.println("Hello, Mr " + initial + " "  + surname);

        System.out.println("Welcome, here is your information");
        
        System.out.println("\n Forname: Steve");
        System.out.println("\n Forename Initial: S");
        System.out.println("\n Surname: Smith");
        System.out.println("\n Age: 22");    
        System.out.println("\n Address: 5 Clove Road");
        System.out.println("\n Postcode: TS117HF");
        System.out.println("");
        
        
        
        String s1 = "Username";
	String s2 = "Incorrect Username";
	String s3 = "Password";
        String s4 = "Incorrect Password";
        

        
        
if (s1.equalsIgnoreCase("Username")) {
System.out.println(" Thank you for logging in! ");
} else if (s1.equalsIgnoreCase("Incorrect Username")) {
System.out.println("Input unsuccessful");
} else {
System.out.println("Something went wrong");




if (s3.equalsIgnoreCase("Password")) {
System.out.println("Thank you for logging in!");
} else if (s3.equalsIgnoreCase("Incorrect Password")) {
System.out.println("Input unsuccessful");
} else {

	






}

        
        
        
       
	       
      
 
}

    
    }
 
    }
    

